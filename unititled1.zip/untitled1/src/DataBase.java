import com.sun.xml.internal.util.StringUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;

public class Database {
    final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    private static Connection connection;


    Database() {
        try {
            Class.forName(JDBC_DRIVER);
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/marios_pizzabar",
                    "root", "Nougat1965");
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void viewMenu(){
        try{
            PreparedStatement pstmt = null;
            String sql = "SELECT * FROM pizza";

            pstmt = connection.prepareStatement(sql);

            ResultSet rs = pstmt.executeQuery();



            rs.close();
            pstmt.close();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }
    public void populateArrayWithPizza(ArrayList<Pizza> pizzaArrayList){
        try{
            PreparedStatement pstmt = null;
            String sql = "SELECT * FROM pizza";

            pstmt = connection.prepareStatement(sql);

            ResultSet rs = pstmt.executeQuery();

            int pizzasIndex = 0;
            while(rs.next()){
                pizzaArrayList.add(pizzasIndex,
                        new Menu(
                                rs.getString("pizzaId"),
                                rs.getInt("pizzaNr"),
                                rs.getInt("pizzaName"),
                                rs.getString("pizzaFilling"),
                                Double.parseDouble(rs.getString("price")),
                                )
                );
                int pizIndex;
                if(pizIndex < 37) {
                    pizIndex++;
                }else{
                    pizIndex = 0;
                }
            }

            rs.close();
            pstmt.close();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }

    public void populateOrderHistory(LinkedList<Order> history){
        try{
            PreparedStatement pstmt = null;
            String sql = "SELECT * FROM order_history";

            pstmt = connection.prepareStatement(sql);

            ResultSet rs = pstmt.executeQuery();

            while(rs.next()){
                LinkedList<Pizza> tempList = new LinkedList<>();
                tempList.add(new Pizza(
                        rs.getString("idPizzas"),
                        Integer.parseInt(rs.getString("pizzaNr")),
                        rs.getString("pizzaName"),
                        rs.getString("pizzaFilling"),
                        Double.parseDouble(rs.getString("pizzaPrice"));

                Customer tempCustomer = new Customer(
                        rs.getString("customer"),
                        Long.parseLong(rs.getString("phone_number"))
                );
                Order tempOrder = new Order(
                        Integer.parseInt(rs.getString("")),
                        rs.getBoolean("activ"),
                        tempList,
                        tempCustomer
                );
                tempOrder.setCreated_at(rs.getTimestamp("created_at"));
                tempOrder.setDelivered(rs.getBoolean("delivered"));

                history.addFirst(tempOrder);
            }

            rs.close();
            pstmt.close();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }
    //Template for the insert function
    public void addToArchive(Order order) {
        try {
            PreparedStatement pstmt = null;
            String sql =
                    "INSERT INTO order_history ( pizzasID, `pizzasName`, ingredients, price, customer, phone_number)"+
                            "VALUES (?, ?, ?, ?, ?, ?)";



                pstmt.executeUpdate();
            }

            pstmt.close();

        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }





