import com.sun.xml.internal.ws.util.StringUtils;
import java.io.PrintStream;
import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Alfonso extends Restaurant {
    Menu menu;
    LinkedList<Customer> currentCustomer = new LinkedList();
    LinkedList<Pizza> customerPizza = new LinkedList();
    ActiveOrders activeOrders;
    ConsoleColour cc = new ConsoleColour();

    Alfonso(Menu menu, ActiveOrders activeOrders) {
        this.menu = menu;
        this.activeOrders = activeOrders;
    }

    public void startOrder(String name, long number) {
        this.currentCustomer.add(new Customer(name, number));
    }

    public boolean addPizzaToOrderByName(String pizzaName, LinkedList<Pizza> currentPizzas) {
        this.menu.viewPizzaByName(pizzaName);

        for(int i = 0; i < this.menu.menuPizzas.size(); ++i) {
            if (((Pizza)this.menu.menuPizzas.get(i)).getName().toLowerCase().equals(pizzaName.toLowerCase())) {
                this.customerPizza.add(this.menu.menuPizzas.get(i));
                return true;
            }
        }

        return false;
    }

    public void addPizzaToOrderById(int pizzaId) {
        this.menu.viewPizzaByID(pizzaId);
        this.customerPizza.add(this.menu.menuPizzas.get(pizzaId - 1));
    }

    public void addPizzaToOrderByIngredients(String ingredients) {
        this.menu.viewPizzaByIngredients(ingredients, this.input, this.customerPizza);
    }

    public void selectionHelper(Scanner input, boolean isRemote, String customerName, Long phoneNum, LinkedList<Pizza> currentPizzas) {
        boolean check = false;
        this.startOrder(customerName, phoneNum);
        System.out.println("Choose pizza:\n1 -- By Name\n2 -- By ID\n3 -- By Ingredients\n0 -- Return (Cancels Order)");

        PrintStream var10000;
        StringBuilder var10001;
        ConsoleColour var10002;
        try {
            int selection = input.nextInt();
            String theGreaterSwallower;
            switch(selection) {
                case 0:
                default:
                    break;
                case 1:
                    System.out.println("Enter pizza name:");
                    theGreaterSwallower = input.nextLine();
                    String pizzaName = input.nextLine();
                    check = this.addPizzaToOrderByName(pizzaName, currentPizzas);
                    break;
                case 2:
                    System.out.println("Enter pizza ID:");
                    int pizzaId = input.nextInt();
                    this.addPizzaToOrderById(pizzaId);
                    break;
                case 3:
                    System.out.println("Enter pizza ingredient(s):");
                    theGreaterSwallower = input.nextLine();
                    String pizzaIng = input.nextLine();
                    this.addPizzaToOrderByIngredients(pizzaIng);
            }

            if (selection > 0 && selection < 4) {
                if (selection == 1 && !check) {
                    var10000 = System.out;
                    var10001 = new StringBuilder();
                    var10002 = this.cc;
                    var10001 = var10001.append("\u001b[0;31m").append("No such element error!\n");
                    var10002 = this.cc;
                    var10000.println(var10001.append("\u001b[0m").toString());
                    this.selectionHelper(input, isRemote, customerName, phoneNum, currentPizzas);
                } else {
                    currentPizzas.add(this.customerPizza.getLast());
                }

                var10000 = System.out;
                var10001 = (new StringBuilder()).append("Would you like to add another pizza to this order?\n1-");
                var10002 = this.cc;
                var10001 = var10001.append("\u001b[0;32m").append("'YES'");
                var10002 = this.cc;
                var10001 = var10001.append("\u001b[0m").append(" | 2-");
                var10002 = this.cc;
                var10001 = var10001.append("\u001b[0;31m").append("'NO'");
                var10002 = this.cc;
                var10000.println(var10001.append("\u001b[0m").toString());
                int addMore = input.nextInt();
                if (addMore == 1) {
                    this.selectionHelper(input, isRemote, customerName, phoneNum, currentPizzas);
                } else {
                    this.activeOrders.addOrder(isRemote, currentPizzas, (Customer)this.currentCustomer.getLast());
                    this.printLastPizza();
                }
            }
        } catch (InputMismatchException var12) {
            var10000 = System.out;
            var10001 = new StringBuilder();
            var10002 = this.cc;
            var10001 = var10001.append("\u001b[0;31m").append("Input mismatch error!\n");
            var10002 = this.cc;
            var10000.println(var10001.append("\u001b[0m").toString());
            input.nextLine();
            this.selectionHelper(input, isRemote, customerName, phoneNum, currentPizzas);
        } catch (NoSuchElementException var13) {
            var10000 = System.out;
            var10001 = new StringBuilder();
            var10002 = this.cc;
            var10001 = var10001.append("\u001b[0;31m").append("No such element error!\n");
            var10002 = this.cc;
            var10000.println(var10001.append("\u001b[0m").toString());
            this.selectionHelper(input, isRemote, customerName, phoneNum, currentPizzas);
        } catch (IndexOutOfBoundsException var14) {
            var10000 = System.out;
            var10001 = new StringBuilder();
            var10002 = this.cc;
            var10001 = var10001.append("\u001b[0;31m").append("Out of bounds error!\n");
            var10002 = this.cc;
            var10000.println(var10001.append("\u001b[0m").toString());
            this.selectionHelper(input, isRemote, customerName, phoneNum, currentPizzas);
        }

    }

    public void printLastPizza() {
        PrintStream var10000;
        StringBuilder var10001;
        ConsoleColour var10002;
        if (this.activeOrders.getActiveOrders().size() > 0) {
            System.out.println("Receipt:");

            for(int i = 0; i < ((Order)this.activeOrders.getActiveOrders().getLast()).getItems().size(); ++i) {
                System.out.println(((Order)this.activeOrders.getActiveOrders().getLast()).getItems().get(i));
            }

            var10000 = System.out;
            var10001 = new StringBuilder();
            var10002 = this.cc;
            var10001 = var10001.append("\u001b[0;32m").append("Total: ").append(((Order)this.activeOrders.getActiveOrders().getLast()).getPrice()).append("kr.\n");
            var10002 = this.cc;
            var10000.println(var10001.append("\u001b[0m").toString());
        } else {
            var10000 = System.out;
            var10001 = new StringBuilder();
            var10002 = this.cc;
            var10001 = var10001.append("\u001b[0;31m").append("N/A\n");
            var10002 = this.cc;
            var10000.println(var10001.append("\u001b[0m").toString());
        }

    }

    public void createOrder() {
        boolean isRemote = false;
        System.out.println("Please enter customer name:");
        String customerName = this.input.nextLine();
        PrintStream var10000 = System.out;
        StringBuilder var10001 = (new StringBuilder()).append("Is it ordered by phone?\n1-");
        ConsoleColour var10002 = this.cc;
        var10001 = var10001.append("\u001b[0;32m").append("'YES'");
        var10002 = this.cc;
        var10001 = var10001.append("\u001b[0m").append(" | 2-");
        var10002 = this.cc;
        var10001 = var10001.append("\u001b[0;31m").append("'NO'");
        var10002 = this.cc;
        var10000.println(var10001.append("\u001b[0m").toString());
        int byPhone = this.input.nextInt();
        if (byPhone == 1) {
            isRemote = true;
        }

        System.out.println("Please enter customer phone number:");
        Long phoneNum = this.input.nextLong();
        LinkedList<Pizza> currentPizzas = new LinkedList();
        this.selectionHelper(this.input, isRemote, customerName, phoneNum, currentPizzas);
    }

    public void processActiveOrder() {
        PrintStream var10000;
        StringBuilder var10001;
        ConsoleColour var10002;
        if (this.activeOrders.getActiveOrders().size() > 0) {
            var10000 = System.out;
            var10001 = new StringBuilder();
            var10002 = this.cc;
            var10001 = var10001.append("\u001b[0;32m").append("There are ").append(this.activeOrders.getActiveOrders().size()).append(" active orders");
            var10002 = this.cc;
            var10000.println(var10001.append("\u001b[0m").toString());
            System.out.println("1 -- Deliver Order\n2 -- Abandon Order\n0 -- Return");
            int selection = this.input.nextInt();
            switch(selection) {
                case 0:
                default:
                    break;
                case 1:
                    this.viewActiveOrders();
                    System.out.println("Enter order ID: ");
                    int id1 = this.input.nextInt();
                    this.deliver(id1);
                    break;
                case 2:
                    this.viewActiveOrders();
                    System.out.println("Enter order ID: ");
                    int id2 = this.input.nextInt();
                    this.abandon(id2);
            }
        } else {
            var10000 = System.out;
            var10001 = new StringBuilder();
            var10002 = this.cc;
            var10001 = var10001.append("\u001b[0;31m").append("No active orders to process\n");
            var10002 = this.cc;
            var10000.println(var10001.append("\u001b[0m").toString());
        }

    }

    public void deliver(int id) {
        boolean check = false;

        PrintStream var10000;
        StringBuilder var10001;
        ConsoleColour var10002;
        for(int i = 0; i < this.activeOrders.getActiveOrders().size(); ++i) {
            if (id == ((Order)this.activeOrders.getActiveOrders().get(i)).id && ((Order)this.activeOrders.getActiveOrders().get(i)).isReady()) {
                ((Order)this.activeOrders.getActiveOrders().get(i)).setDelivered(true);
                this.activeOrders.archiveOrder(((Order)this.activeOrders.getActiveOrders().get(i)).getId());
                check = true;
            } else if (id == ((Order)this.activeOrders.getActiveOrders().get(i)).id) {
                var10000 = System.out;
                var10001 = new StringBuilder();
                var10002 = this.cc;
                var10001 = var10001.append("\u001b[0;31m").append("Order is not ready to be delivered");
                var10002 = this.cc;
                var10000.println(var10001.append("\u001b[0m").toString());
                check = true;
            }
        }

        if (!check) {
            var10000 = System.out;
            var10001 = new StringBuilder();
            var10002 = this.cc;
            var10001 = var10001.append("\u001b[0;31m").append("Order ID: ").append(id).append(" does not exist\n");
            var10002 = this.cc;
            var10000.println(var10001.append("\u001b[0m").toString());
        } else {
            var10000 = System.out;
            var10001 = new StringBuilder();
            var10002 = this.cc;
            var10001 = var10001.append("\u001b[0;32m").append("Finished processing Order ID: ").append(id).append("\n");
            var10002 = this.cc;
            var10000.println(var10001.append("\u001b[0m").toString());
        }

    }

    public void abandon(int id) {
        boolean check = false;

        for(int i = 0; i < this.activeOrders.getActiveOrders().size(); ++i) {
            if (id == ((Order)this.activeOrders.getActiveOrders().get(i)).id) {
                ((Order)this.activeOrders.getActiveOrders().get(i)).setDelivered(false);
                this.activeOrders.archiveOrder(((Order)this.activeOrders.getActiveOrders().get(i)).getId());
                check = true;
            }
        }

        PrintStream var10000;
        StringBuilder var10001;
        ConsoleColour var10002;
        if (!check) {
            var10000 = System.out;
            var10001 = new StringBuilder();
            var10002 = this.cc;
            var10001 = var10001.append("\u001b[0;31m").append("Order ID: ").append(id).append(" does not exist\n");
            var10002 = this.cc;
            var10000.println(var10001.append("\u001b[0m").toString());
        } else {
            var10000 = System.out;
            var10001 = new StringBuilder();
            var10002 = this.cc;
            var10001 = var10001.append("\u001b[0;32m").append("Finished processing Order ID: ").append(id).append("\n");
            var10002 = this.cc;
            var10000.println(var10001.append("\u001b[0m").toString());
        }

    }

    public void viewActiveOrders() {
        PrintStream var10000 = System.out;
        StringBuilder var10001 = new StringBuilder();
        ConsoleColour var10002 = this.cc;
        var10001 = var10001.append("\u001b[1;34m").append("Active Orders:\n--------------");
        var10002 = this.cc;
        var10000.println(var10001.append("\u001b[0m").toString());
        String view = "";

        StringBuilder var7;
        ConsoleColour var8;
        for(int i = 0; i < this.activeOrders.getActiveOrders().size(); ++i) {
            view = view + "\n#" + ((Order)this.activeOrders.getActiveOrders().get(i)).getId() + " '" + ((Order)this.activeOrders.getActiveOrders().get(i)).customer.name + "' (" + ((Order)this.activeOrders.getActiveOrders().get(i)).customer.number + ") - ";
            if (((Order)this.activeOrders.getActiveOrders().get(i)).remote) {
                view = view + "Ordered by Phone\n";
            } else {
                view = view + "Ordered in Person\n";
            }

            if (((Order)this.activeOrders.getActiveOrders().get(i)).isReady()) {
                var7 = (new StringBuilder()).append(view);
                var8 = this.cc;
                var7 = var7.append("\u001b[0;32m").append("-Ready-\n");
                var8 = this.cc;
                view = var7.append("\u001b[0m").toString();
            } else {
                var7 = (new StringBuilder()).append(view);
                var8 = this.cc;
                var7 = var7.append("\u001b[0;31m").append("-Not Ready-\n");
                var8 = this.cc;
                view = var7.append("\u001b[0m").toString();
            }

            view = view + "Order(s):\n";
            double sum = 0.0D;

            for(int j = 0; j < ((Order)this.activeOrders.getActiveOrders().get(i)).getItems().size(); ++j) {
                view = view + ((Pizza)((Order)this.activeOrders.getActiveOrders().get(i)).getItems().get(j)).getId();
                if (((Pizza)((Order)this.activeOrders.getActiveOrders().get(i)).getItems().get(j)).getId() < 10) {
                    view = view + " --- ";
                } else {
                    view = view + " -- ";
                }

                var7 = (new StringBuilder()).append(view);
                var8 = this.cc;
                var7 = var7.append("\u001b[0;32m").append("\"").append(((Pizza)((Order)this.activeOrders.getActiveOrders().get(i)).getItems().get(j)).getName()).append("\"");
                var8 = this.cc;
                view = var7.append("\u001b[0m").append(" --- ").toString();

                for(int k = 0; k < ((Pizza)((Order)this.activeOrders.getActiveOrders().get(i)).getItems().get(j)).getIngredients().length; ++k) {
                    view = view + StringUtils.capitalize(((Pizza)((Order)this.activeOrders.getActiveOrders().get(i)).getItems().get(j)).getIngredients()[k].toLowerCase());
                    if (k < ((Pizza)((Order)this.activeOrders.getActiveOrders().get(i)).getItems().get(j)).getIngredients().length - 2) {
                        view = view + ", ";
                    } else if (k < ((Pizza)((Order)this.activeOrders.getActiveOrders().get(i)).getItems().get(j)).getIngredients().length - 1) {
                        view = view + ", and ";
                    }
                }

                view = view + " --- " + ((Pizza)((Order)this.activeOrders.getActiveOrders().get(i)).getItems().get(j)).getPrice() + "kr.\n";
                sum += ((Pizza)((Order)this.activeOrders.getActiveOrders().get(i)).getItems().get(j)).getPrice();
            }

            var7 = (new StringBuilder()).append(view);
            var8 = this.cc;
            var7 = var7.append("\u001b[0;32m").append("Total: ").append(sum).append("kr.\n");
            var8 = this.cc;
            view = var7.append("\u001b[0m").toString();
        }

        if (view.equals("")) {
            var7 = new StringBuilder();
            var8 = this.cc;
            var7 = var7.append("\u001b[0;31m").append("No active orders");
            var8 = this.cc;
            view = var7.append("\u001b[0m").toString();
        }

        System.out.println(view);
        var10000 = System.out;
        var10001 = new StringBuilder();
        var10002 = this.cc;
        var10001 = var10001.append("\u001b[1;34m").append("--------------");
        var10002 = this.cc;
        var10000.println(var10001.append("\u001b[0m").toString());
    }
}
